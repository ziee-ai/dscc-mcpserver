#!/usr/bin/env Rscript
# Simple mcpserver demo with admin SPA.
#
#   MCPSERVER_ADMIN_TOKEN=... Rscript demo-server.R
#
# Then open http://127.0.0.1:7777/admin/ui in a browser and log in
# with $MCPSERVER_ADMIN_TOKEN.

suppressPackageStartupMessages(library(mcpserver))

PORT  <- 7777L
HOST  <- "127.0.0.1"
DBDIR <- "/tmp/mcpserver-demo"
DBPATH <- file.path(DBDIR, "state.db")
dir.create(DBDIR, recursive = TRUE, showWarnings = FALSE)

# Persistent users + tokens store
store <- new_mcp_store(driver = "sqlite", path = DBPATH)

# OAuth AS that signs user-bound JWTs against the store
oauth_as <- oauth_server_config(
  issuer           = sprintf("http://%s:%d", HOST, PORT),
  audience         = "mcp",
  store            = store,
  scopes_supported = c("mcp:read", "mcp:write")
)

# Minimal MCP server with one tool that reports the caller's identity
mcp <- new_server(name = "demo", version = "0.1.0")

add_capability(mcp, new_tool(
  "whoami",
  "Identify the calling user (derived from the JWT subject).",
  schema(list()),
  handler = function(args, ctx) {
    response_text(sprintf(
      "user_id=%s name=%s is_admin=%s scopes=%s",
      ctx$user_id   %||% "(anonymous)",
      ctx$user_name %||% "(anonymous)",
      ctx$is_admin,
      paste(ctx$auth_scopes, collapse = ",")
    ))
  }))

cat(sprintf("MCP endpoint  : http://%s:%d/mcp\n",       HOST, PORT))
cat(sprintf("Admin UI       : http://%s:%d/admin/ui\n", HOST, PORT))
cat(sprintf("Bootstrap token: %s\n",
            Sys.getenv("MCPSERVER_ADMIN_TOKEN", unset = "(unset)")))
cat("State DB       :", DBPATH, "\n\n")

serve_http(
  mcp,
  host            = HOST,
  port            = PORT,
  oauth_as        = oauth_as,
  admin           = list(
    bootstrap_token = Sys.getenv("MCPSERVER_ADMIN_TOKEN"),
    ui              = TRUE
  ),
  allowed_origins = c(sprintf("http://%s", HOST),
                      sprintf("http://%s:%d", HOST, PORT))
)
